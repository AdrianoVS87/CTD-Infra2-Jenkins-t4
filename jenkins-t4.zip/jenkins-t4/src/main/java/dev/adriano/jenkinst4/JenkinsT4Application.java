package dev.adriano.jenkinst4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JenkinsT4Application {

	public static void main(String[] args) {
		SpringApplication.run(JenkinsT4Application.class, args);
	}

}
