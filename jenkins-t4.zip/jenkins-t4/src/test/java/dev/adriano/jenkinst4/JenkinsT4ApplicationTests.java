package dev.adriano.jenkinst4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JenkinsT4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
